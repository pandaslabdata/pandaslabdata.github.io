"""Pandas Lab chart style — dark wool sky, gold stitches
Usage:  import pandaslab_style as pl; fig, ax = pl.new_chart()
Palette validated for color-blind safety on the dark surface"""
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

SKY      = "#0b111a"   # surface
INK      = "#e8edf4"   # primary text
INK2     = "#8c96a5"   # secondary text
GOLD_UI  = "#d49318"   # brand gold (titles, stitches)
GRID     = (1, 1, 1, 0.08)

# categorical series colors — fixed order, never cycled
SERIES = ["#c98500", "#199e70", "#3987e5", "#d55181"]  # gold, aqua, blue, magenta
MUTED  = "#3d4a5c"     # de-emphasized bars behind a highlight

def new_chart(figsize=(9, 5.5)):
    plt.rcParams.update({
        "figure.facecolor": SKY, "axes.facecolor": SKY,
        "text.color": INK, "axes.labelcolor": INK2,
        "xtick.color": INK2, "ytick.color": INK2,
        "font.family": "DejaVu Sans", "font.size": 11,
        "axes.edgecolor": INK2, "axes.linewidth": 0.6,
    })
    fig, ax = plt.subplots(figsize=figsize, dpi=200)
    for s in ["top", "right"]:
        ax.spines[s].set_visible(False)
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    return fig, ax

def stitch_frame(fig):
    """the signature gold running-stitch border"""
    r = mpatches.FancyBboxPatch((0.012, 0.018), 0.976, 0.964,
        boxstyle="round,pad=0,rounding_size=0.012",
        transform=fig.transFigure, fill=False,
        edgecolor=GOLD_UI, linewidth=1.4, linestyle=(0, (4, 3)), alpha=0.75)
    fig.add_artist(r)

def sign(fig, source):
    fig.text(0.035, 0.035, "PANDAS LAB", color=GOLD_UI,
             fontsize=8.5, fontweight="bold")
    fig.text(0.965, 0.035, source, color=INK2, fontsize=8, ha="right")

def title(fig, main, sub):
    fig.text(0.035, 0.93, main, color=INK, fontsize=15, fontweight="bold")
    fig.text(0.035, 0.875, sub, color=INK2, fontsize=10.5)
