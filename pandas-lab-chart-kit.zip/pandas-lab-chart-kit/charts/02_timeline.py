"""Two lines over time — direct labels at the line ends, one annotation"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pandaslab_style as pl
import matplotlib.pyplot as plt

years  = list(range(1900, 2021, 10))
finds  = [2, 3, 3, 4, 5, 6, 9, 30, 90, 190, 310, 420, 480]   # illustrative
falls  = [5, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9, 9]             # illustrative

fig, ax = pl.new_chart()
ax.grid(axis="y", color=pl.GRID, linewidth=0.8); ax.grid(axis="x", visible=False)
ax.plot(years, finds, color=pl.SERIES[0], linewidth=2.4)
ax.plot(years, falls, color=pl.SERIES[2], linewidth=2.4)
ax.text(years[-1]+2, finds[-1], "found", color=pl.SERIES[0], fontweight="bold", va="center")
ax.text(years[-1]+2, falls[-1]+12, "seen falling", color=pl.SERIES[2], fontweight="bold", va="center")
ax.annotate("the searching explodes,\nthe sky stays the same",
            xy=(1980, 190), xytext=(1915, 300), color=pl.INK, fontsize=10,
            arrowprops=dict(arrowstyle="-", color=pl.INK2, lw=1))
ax.set_xlim(1900, 2042); ax.set_xlabel("year")
fig.subplots_adjust(top=0.82, bottom=0.17, right=0.97)
pl.title(fig, "A map of where we looked",
         "Meteorites recorded per decade — found vs seen falling (illustrative)")
pl.stitch_frame(fig); pl.sign(fig, "Source: your dataset here")
fig.savefig(os.path.join(os.path.dirname(__file__), "02_timeline.png"))
