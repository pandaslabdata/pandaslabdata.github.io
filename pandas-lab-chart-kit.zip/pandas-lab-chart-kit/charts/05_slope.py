"""Before/after slope — two moments, a line per contender, gold on the mover"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pandaslab_style as pl
import matplotlib.pyplot as plt

data = {  # name: (then, now, is_hero)   — illustrative
 "China":     (50, 270, True),
 "USA":       (120, 210, False),
 "Argentina": (30, 90, False),
 "UK":        (40, 55, False),
}
THEN, NOW = "1990", "2020"

fig, ax = pl.new_chart(figsize=(9, 5.5))
ax.grid(visible=False)
for name, (a, b, hero) in data.items():
    c = pl.SERIES[0] if hero else pl.MUTED
    lw = 3 if hero else 2
    ax.plot([0, 1], [a, b], color=c, linewidth=lw, marker="o",
            markersize=7, markeredgecolor=pl.SKY, markeredgewidth=1.2)
    ax.text(-0.04, a, f"{name}  {a}", ha="right", va="center",
            color=pl.INK if hero else pl.INK2,
            fontweight="bold" if hero else "normal", fontsize=10.5)
    ax.text(1.04, b, f"{b}", ha="left", va="center",
            color=pl.SERIES[0] if hero else pl.INK2,
            fontweight="bold" if hero else "normal", fontsize=10.5)
ax.set_xlim(-0.55, 1.25); ax.set_xticks([0, 1]); ax.set_xticklabels([THEN, NOW])
ax.set_yticks([]); 
for s in ["left","bottom"]: ax.spines[s].set_visible(False)
fig.subplots_adjust(top=0.82, bottom=0.12)
pl.title(fig, "Who moved, who stood still",
         "Named species per country, then vs now (illustrative)")
pl.stitch_frame(fig); pl.sign(fig, "Source: your dataset here")
fig.savefig(os.path.join(os.path.dirname(__file__), "05_slope.png"))
