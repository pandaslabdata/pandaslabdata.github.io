"""Ranking bar — one gold highlight, the rest steps back"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pandaslab_style as pl
import matplotlib.pyplot as plt

names  = ["Spinosaurus", "Giganotosaurus", "Carcharodontosaurus", "T. rex"]
values = [15.0, 13.2, 12.3, 12.3]
hero   = "T. rex"   # the bar your story is about

fig, ax = pl.new_chart()
colors = [pl.SERIES[0] if n == hero else pl.MUTED for n in names]
bars = ax.barh(names[::-1], values[::-1], color=colors[::-1], height=0.62)
for b, v in zip(bars, values[::-1]):
    ax.text(v + 0.18, b.get_y() + b.get_height()/2, f"{v:g} m",
            va="center", color=pl.INK, fontsize=10.5, fontweight="bold")
ax.set_xlim(0, 17); ax.set_xlabel("estimated length (m)")
fig.subplots_adjust(left=0.26, top=0.82, bottom=0.17)
pl.title(fig, "The crown is not about size",
         "Estimated length of the four giant meat-eaters")
pl.stitch_frame(fig); pl.sign(fig, "Source: your dataset here")
fig.savefig(os.path.join(os.path.dirname(__file__), "01_ranking.png"))
