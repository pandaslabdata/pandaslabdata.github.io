"""Hero number + share bar — when one number IS the story"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pandaslab_style as pl
import matplotlib.pyplot as plt

parts  = [("Antarctica", 68.1, pl.SERIES[0]), ("Deserts", 22.0, pl.SERIES[2]),
          ("Everywhere else", 9.9, pl.MUTED)]

fig = plt.figure(figsize=(9, 5.5), dpi=200); fig.patch.set_facecolor(pl.SKY)
fig.text(0.5, 0.60, "68.1%", color=pl.SERIES[0], fontsize=64,
         fontweight="bold", ha="center")
fig.text(0.5, 0.48, "of all catalogued meteorites were picked up in Antarctica",
         color=pl.INK, fontsize=13, ha="center")
ax = fig.add_axes([0.08, 0.24, 0.84, 0.09]); ax.set_facecolor(pl.SKY)
left = 0
for name, v, c in parts:
    ax.barh(0, v - 0.6, left=left + 0.3, color=c, height=1)  # 0.6 = the 2px gap
    ax.text(left + v/2, -1.6, f"{name}  {v:g}%", color=pl.INK2,
            fontsize=9.5, ha="center")
    left += v
ax.set_xlim(0, 100); ax.set_ylim(-2.4, 1); ax.axis("off")
pl.stitch_frame(fig); pl.sign(fig, "Source: your dataset here")
fig.savefig(os.path.join(os.path.dirname(__file__), "04_hero.png"))
