"""The waffle — 100 felt squares, the share you can count by eye"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pandaslab_style as pl
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

parts = [("Antarctica", 68, pl.SERIES[0]), ("Deserts", 22, pl.SERIES[2]),
         ("Everywhere else", 10, pl.MUTED)]   # must total 100

fig, ax = pl.new_chart(figsize=(9, 5.5))
ax.grid(visible=False); ax.axis("off")
colors = []
for name, n, c in parts: colors += [c] * n
k = 0
for row in range(10):
    for col in range(10):
        ax.add_patch(mpatches.FancyBboxPatch((col*1.0, 9-row*1.0), 0.82, 0.82,
            boxstyle="round,pad=0,rounding_size=0.12", facecolor=colors[k],
            edgecolor=pl.SKY, linewidth=1.2))
        k += 1
ax.set_xlim(-0.3, 15.5); ax.set_ylim(-0.6, 10.4); ax.set_aspect("equal")
y = 8.6
for name, n, c in parts:
    ax.add_patch(mpatches.FancyBboxPatch((10.9, y), 0.62, 0.62,
        boxstyle="round,pad=0,rounding_size=0.12", facecolor=c, edgecolor=pl.SKY))
    ax.text(11.8, y+0.30, f"{name} · {n}", color=pl.INK, fontsize=11, va="center")
    y -= 1.1
ax.text(10.9, 4.6, "1 square = 1% of the catalogue", color=pl.INK2, fontsize=9.5)
fig.subplots_adjust(top=0.82, bottom=0.08)
pl.title(fig, "Count it with your eyes",
         "Out of every 100 catalogued meteorites, where were they found")
pl.stitch_frame(fig); pl.sign(fig, "Source: your dataset here")
fig.savefig(os.path.join(os.path.dirname(__file__), "06_waffle.png"))
