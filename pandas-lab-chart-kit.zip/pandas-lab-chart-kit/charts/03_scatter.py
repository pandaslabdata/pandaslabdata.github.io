"""Scatter with labeled outliers — the story points get names, the crowd stays quiet"""
import sys, os; sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pandaslab_style as pl
import matplotlib.pyplot as plt

data = {  # name: (length m, mass t, is_hero)
 "Stegosaurus": (9, 5, False), "T. rex": (12.3, 9, False),
 "Giganotosaurus": (13.2, 8.2, False), "Spinosaurus": (15, 7.4, False),
 "Diplodocus": (26, 15, False), "Dreadnoughtus": (26, 48, False),
 "Patagotitan": (31, 57, False), "Argentinosaurus": (35, 75, True),
}
fig, ax = pl.new_chart()
ax.grid(axis="y", color=pl.GRID, linewidth=0.8)
for name, (x, y, hero) in data.items():
    c = pl.SERIES[0] if hero else pl.SERIES[2]
    ax.scatter(x, y, s=90 if hero else 55, color=c, zorder=3,
               edgecolor=pl.SKY, linewidth=1.5)
    if hero or y > 40 or name in ("T. rex", "Stegosaurus"):
        ax.text(x, y + 2.5, name, color=pl.INK, fontsize=9.5, ha="center",
                fontweight="bold" if hero else "normal")
ax.set_xlabel("estimated length (m)"); ax.set_ylabel("estimated mass (t)")
ax.set_xlim(5, 40); ax.set_ylim(0, 88)
fig.subplots_adjust(top=0.82, bottom=0.15)
pl.title(fig, "Long is not the same as heavy",
         "Each dot is one animal — label only the ones your story needs")
pl.stitch_frame(fig); pl.sign(fig, "Source: your dataset here")
fig.savefig(os.path.join(os.path.dirname(__file__), "03_scatter.png"))
