PANDAS LAB CHART KIT
====================
4 matplotlib chart templates in the Pandas Lab style
(dark wool sky, gold stitches, one gold hero per chart)

CONTENTS
  pandaslab_style.py   the shared style (palette, stitch frame, signature)
  charts/01_ranking.py   + png   ranking bar with one highlight
  charts/02_timeline.py  + png   two lines over time, direct labels
  charts/03_scatter.py   + png   scatter with labeled outliers
  charts/04_hero.py      + png   hero number + share bar
  GUIDE.pdf            what each chart is for and how to make it yours

QUICK START
  pip install matplotlib
  python charts/01_ranking.py

Free for any use - a mention of pandaslab.it makes the pandas happy
info@pandaslab.it
