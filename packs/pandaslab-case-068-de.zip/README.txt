Pandas-Lab-Fallpaket - Fall 068

Inhalt:
- summary.pdf: der ganze Fall (Frage, Beweise, Modell, Urteil, jede Quelle mit Link)
- chart_*.png: die Filzdiagramme in hoher Auflösung
- data.csv: die Werte der Diagramme und die Quellenliste mit ihren Sicherheitsetiketten

Kostenlos für den privaten Gebrauch und den Unterricht mit Quellenangabe (Pandas Lab, pandaslab.it). Kein Weiterverkauf.
Der Fall online: https://pandaslab.it/de/cases/068/
