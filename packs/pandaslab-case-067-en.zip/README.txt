Pandas Lab case pack - Case 067

Inside:
- summary.pdf: the whole case (question, evidence, model, verdict, every source with its link)
- chart_*.png: the felt charts, in high resolution
- data.csv: the values behind the charts and the list of sources with their certainty labels

Free for personal and classroom use with credit (Pandas Lab, pandaslab.it). Not for resale.
The case online: https://pandaslab.it/cases/067/
