Expediente de Pandas Lab - Caso 067

Contiene:
- summary.pdf: el caso completo (pregunta, pruebas, modelo, veredicto, cada fuente con su enlace)
- chart_*.png: los gráficos de fieltro en alta resolución
- data.csv: los valores de los gráficos y la lista de fuentes con sus etiquetas de certeza

Gratis para uso personal y en clase, citando la fuente (Pandas Lab, pandaslab.it). Prohibida la reventa.
El caso en línea: https://pandaslab.it/es/cases/067/
