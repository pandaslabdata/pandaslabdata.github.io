Dossier Pandas Lab - Affaire 067

Contenu :
- summary.pdf : l'affaire complète (question, preuves, modèle, verdict, chaque source avec son lien)
- chart_*.png : les graphiques en feutre, en haute résolution
- data.csv : les valeurs des graphiques et la liste des sources avec leurs étiquettes de certitude

Gratuit pour un usage personnel et en classe, avec mention de la source (Pandas Lab, pandaslab.it). Revente interdite.
L'affaire en ligne : https://pandaslab.it/fr/cases/067/
