Fascicolo Pandas Lab - Caso 067

Contiene:
- summary.pdf: il caso completo (domanda, prove, modello, verdetto, ogni fonte con il suo link)
- chart_*.png: i grafici in feltro, in alta risoluzione
- data.csv: i valori dei grafici e l'elenco delle fonti con le etichette di certezza

Gratuito per uso personale e in classe, citando la fonte (Pandas Lab, pandaslab.it). Non rivendibile.
Il caso online: https://pandaslab.it/it/cases/067/
